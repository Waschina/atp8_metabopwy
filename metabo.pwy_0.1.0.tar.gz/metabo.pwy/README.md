Quick-Start

```R
library(metabo.pwy)

db  <- init.db(db.source = "metacyc") # init biochem database
adl <- init.adduct.table()            # init adducts (user decision req.) 

# get all theoretical metabolit-X-adduct combination
db.met.adducts <- db2adducts(db, adl, ppm.range = 1) # This takes some time
```


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# S4 Object for FTICR-MS Experiment   #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
BioChemDB <- setClass(
  # Name Of Class
  "MSExperiment",

  # Slot definition
  slots = c(
    exp.name           = "character",
    sample.description = "data.table",
    pos.intensities    = "matrix",
    neg.intensities    = "matrix",
    pos.mz             = "numeric",
    neg.mz             = "numeric",
    object.date        = "character",
    metabo.pwy.version = "character",

    peak.annotation    = "data.table",
    stat.tests         = "list"
  ),

  # Default Slot Values
  prototype = list(
    peak.annotation    = data.table(),
    stat.tests         = list()
  )
)

setMethod(
  f          = "initialize",
  signature  = "MSExperiment",

  definition = function(.Object,
                        exp.name,
                        sample.description,
                        pos.intensities,
                        neg.intensities,
                        pos.mz,
                        neg.mz) {

    # save analysis meta info
    .Object@object.date        <- date()
    .Object@metabo.pwy.version <- as.character(packageVersion("metabo.pwy"))

    # save contents
    .Object@exp.name           <- exp.name
    .Object@sample.description <- sample.description
    .Object@pos.intensities    <- pos.intensities
    .Object@neg.intensities    <- neg.intensities
    .Object@pos.mz             <- pos.mz
    .Object@neg.mz             <- neg.mz

    return(.Object)
  }
)

setGeneric(name="annotate.mz.peaks",
           def=function(.Object, biochem.db)
           {
             standardGeneric("annotate.mz.peaks")
           }
)

setMethod(f          = "annotate.mz.peaks",
          signature  = "MSExperiment",
          definition = function(.Object, biochem.db) {
            db <- biochem.db

            # pos
            dt.pos <- lapply(.Object@pos.mz, function(x) {
              tmp <- copy(db@met.adducts$pos[x <= mz.pred+mz.ppme & x > mz.pred-mz.ppme])
              tmp[, query.mz := x]
              return(tmp)
            })
            dt.pos <- rbindlist(dt.pos)


            # neg
            dt.neg <- lapply(.Object@neg.mz, function(x) {
              tmp <- copy(db@met.adducts$neg[x <= mz.pred+mz.ppme & x > mz.pred-mz.ppme])
              tmp[, query.mz := x]
              return(tmp)
            })
            dt.neg <- rbindlist(dt.neg)

            dt <- rbind(dt.pos, dt.neg)

            .Object@peak.annotation <- dt

            return(.Object)
          }
)

setGeneric(name="peak.group.comparison",
           def=function(.Object, colname, grpA, grpB, do.lme)
           {
             standardGeneric("peak.group.comparison")
           }
)

setMethod(f          = "peak.group.comparison",
          signature  = "MSExperiment",
          definition = function(.Object, colname, grpA, grpB, do.lme = T) {
            stat.test.name <- paste0("stat.pgc_",
                                     colname,"_",
                                     grpA,"--VS--",grpB)

            grpA_cn_pos <- .Object@sample.description[get(colname) == grpA, colname.pos]
            grpA_cn_neg <- .Object@sample.description[get(colname) == grpA, colname.neg]

            grpB_cn_pos <- .Object@sample.description[get(colname) == grpB, colname.pos]
            grpB_cn_neg <- .Object@sample.description[get(colname) == grpB, colname.neg]

            grpA_cn_pos <- grpA_cn_pos[!is.na(grpA_cn_pos)]
            grpA_cn_neg <- grpA_cn_neg[!is.na(grpA_cn_neg)]
            grpB_cn_pos <- grpB_cn_pos[!is.na(grpB_cn_pos)]
            grpB_cn_neg <- grpB_cn_neg[!is.na(grpB_cn_neg)]

            dt.lme <- copy(.Object@sample.description[get(colname) %in% c(grpA,grpB)])

            #
            # pos
            #
            dt.pos <- data.table(mz.meas  = .Object@pos.mz,
                                 ion.mode = "positive",
                                 tt.pval  = NA_real_,
                                 tt.t     = NA_real_,
                                 wt.pval  = NA_real_,
                                 wt.w     = NA_real_,
                                 lme.pval = NA_real_,
                                 lme.isSingular = FALSE,
                                 med.A    = NA_real_,
                                 med.B    = NA_real_,
                                 mean.A   = NA_real_,
                                 mean.B   = NA_real_,
                                 n.A      = length(grpA_cn_pos),
                                 n.B      = length(grpB_cn_pos)
                                 )
            for(i in 1:nrow(.Object@pos.intensities)) {

              inten.A <- .Object@pos.intensities[i, grpA_cn_pos]
              inten.B <- .Object@pos.intensities[i, grpB_cn_pos]

              tt <- t.test(inten.A, inten.B)
              wt <- wilcox.test(inten.A, inten.B)

              dt.pos[i]$med.A   <- median(inten.A)
              dt.pos[i]$med.B   <- median(inten.B)

              dt.pos[i]$mean.A  <- mean(inten.A)
              dt.pos[i]$mean.B  <- mean(inten.B)

              dt.pos[i]$tt.pval <- tt$p.value
              dt.pos[i]$tt.t    <- tt$statistic

              dt.pos[i]$wt.pval <- wt$p.value
              dt.pos[i]$wt.w    <- wt$statistic

              # LME
              if(do.lme) {
                dt.tmp <- copy(dt.lme)[, inten := .Object@pos.intensities[i, colname.pos]]
                dt.tmp[[colname]] <- as.character(dt.tmp[[colname]])
                m0     <- lmer(inten ~                (1 | sample), data = dt.tmp, REML = F)
                m1     <- lmer(inten ~ get(colname) + (1 | sample), data = dt.tmp, REML = F)
                m.aov  <- anova(m0, m1)

                dt.pos[i]$lme.pval       <- m.aov$`Pr(>Chisq)`[2]
                dt.pos[i]$lme.isSingular <- isSingular(m1)
              }

            }

            #
            # neg
            #
            dt.neg <- data.table(mz.meas  = .Object@neg.mz,
                                 ion.mode = "negative",
                                 tt.pval  = NA_real_,
                                 tt.t     = NA_real_,
                                 wt.pval  = NA_real_,
                                 wt.w     = NA_real_,
                                 lme.pval = NA_real_,
                                 lme.isSingular = FALSE,
                                 med.A    = NA_real_,
                                 med.B    = NA_real_,
                                 mean.A   = NA_real_,
                                 mean.B   = NA_real_,
                                 n.A      = length(grpA_cn_neg),
                                 n.B      = length(grpB_cn_neg)
            )
            for(i in 1:nrow(.Object@neg.intensities)) {

              inten.A <- .Object@neg.intensities[i, grpA_cn_neg]
              inten.B <- .Object@neg.intensities[i, grpB_cn_neg]

              tt <- t.test(inten.A, inten.B)
              wt <- wilcox.test(inten.A, inten.B)

              dt.neg[i]$med.A   <- median(inten.A)
              dt.neg[i]$med.B   <- median(inten.B)

              dt.neg[i]$mean.A  <- mean(inten.A)
              dt.neg[i]$mean.B  <- mean(inten.B)

              dt.neg[i]$tt.pval <- tt$p.value
              dt.neg[i]$tt.t    <- tt$statistic

              dt.neg[i]$wt.pval <- wt$p.value
              dt.neg[i]$wt.w    <- wt$statistic

              # LME
              if(do.lme) {
                dt.tmp <- copy(dt.lme)[, inten := .Object@neg.intensities[i, colname.neg]]
                dt.tmp[[colname]] <- as.character(dt.tmp[[colname]])
                m0     <- lmer(inten ~                (1 | sample), data = dt.tmp, REML = F)
                m1     <- lmer(inten ~ get(colname) + (1 | sample), data = dt.tmp, REML = F)
                m.aov  <- anova(m0, m1)

                dt.neg[i]$lme.pval       <- m.aov$`Pr(>Chisq)`[2]
                dt.neg[i]$lme.isSingular <- isSingular(m1)
              }

            }

            .Object@stat.tests[[stat.test.name]] <- list(pos = dt.pos,
                                                         neg = dt.neg)

            return(.Object)
          }
)


# TOBE REPLACED
setGeneric(name="normalize.intensities",
           def=function(.Object)
           {
             standardGeneric("normalize.intensities")
           }
)

setMethod(f          = "normalize.intensities",
          signature  = "MSExperiment",
          definition = function(.Object) {

            # pos
            med.tmp <- apply(.Object@pos.intensities, 2, median)
            .Object@pos.intensities <- t(t(.Object@pos.intensities)/med.tmp)

            # neg
            med.tmp <- apply(.Object@neg.intensities, 2, median)
            .Object@neg.intensities <- t(t(.Object@neg.intensities)/med.tmp)

            return(.Object)
          }
)


setGeneric(name="scale.intensities",
           def=function(.Object, method, ...)
           {
             standardGeneric("scale.intensities")
           }
)

setMethod(f          = "scale.intensities",
          signature  = "MSExperiment",
          definition = function(.Object, method = "median", min.samples.with.peak.value = 0.9, zero.as.na = F,
                                topn = 25) {

            if(method == "median") {
              # ~ ~ #
              # pos #
              # ~ ~ #
              int.pos.tmp   <- .Object@pos.intensities
              if(zero.as.na)
                int.pos.tmp <- ifelse(int.pos.tmp == 0, NA, int.pos.tmp)
              rel.peaks.pos <- which(apply(int.pos.tmp,
                                           1,
                                           function(x) (sum(!is.na(x))/length(x))) >= min.samples.with.peak.value)
              if(length(rel.peaks.pos) == 0)
                stop(paste0("POS: No Peaks passed the minimum number of samples with values for the focal peak. (",
                            min.samples.with.peak.value*100," %)"))
              if(length(rel.peaks.pos) < 25)
                warning(paste0("POS: Only ",length(rel.peaks.pos),
                               " peaks passed the minimum number of samples with values for the focal peak filter. (",
                               min.samples.with.peak.value*100," %)"))
              # actual scaling here
              med.tmp <- apply(.Object@pos.intensities[rel.peaks.pos,], 2, median)
              .Object@pos.intensities <- t(t(.Object@pos.intensities)/med.tmp)
              cat("POS:",length(rel.peaks.pos), "Peaks were used for median scaling.\n")

              # ~ ~ #
              # neg #
              # ~ ~ #
              int.neg.tmp   <- .Object@neg.intensities
              if(zero.as.na)
                int.neg.tmp <- ifelse(int.neg.tmp == 0, NA, int.neg.tmp)
              rel.peaks.neg <- which(apply(int.neg.tmp,
                                           1,
                                           function(x) (sum(!is.na(x))/length(x))) >= min.samples.with.peak.value)
              if(length(rel.peaks.neg) == 0)
                stop(paste0("NEG: No Peaks passed the minimum number of samples with values for the focal peak. (",
                            min.samples.with.peak.value*100," %)"))
              if(length(rel.peaks.neg) < 25)
                warning(paste0("NEG: Only ",length(rel.peaks.neg),
                               " peaks passed the minimum number of samples with values for the focal peak filter. (",
                               min.samples.with.peak.value*100," %)"))
              # actual scaling here
              med.tmp <- apply(.Object@neg.intensities[rel.peaks.neg,], 2, median)
              .Object@neg.intensities <- t(t(.Object@neg.intensities)/med.tmp)
              cat("NEG:",length(rel.peaks.neg), "Peaks were used for median scaling.\n")

            }

            if(method == "median.topn") {

              # ~ ~ #
              # pos #
              # ~ ~ #
              int.pos.tmp   <- .Object@pos.intensities
              peak.medians  <- apply(int.pos.tmp, 1, median)
              rel.peaks.pos <- which(order(-peak.medians) <= topn)
              if(length(rel.peaks.pos) == 0)
                stop(paste0("POS: No peaks for median.topn"))

              # actual scaling here
              med.tmp <- apply(.Object@pos.intensities[rel.peaks.pos,], 2, median)
              .Object@pos.intensities <- t(t(.Object@pos.intensities)/med.tmp)
              cat("POS:",length(rel.peaks.pos), "Peaks were used for median scaling.\n")

              # ~ ~ #
              # neg #
              # ~ ~ #
              int.neg.tmp   <- .Object@neg.intensities
              peak.medians  <- apply(int.neg.tmp, 1, median)
              rel.peaks.neg <- which(order(-peak.medians) <= topn)
              if(length(rel.peaks.neg) == 0)
                stop(paste0("NEG: No peaks for median.topn"))

              # actual scaling here
              med.tmp <- apply(.Object@neg.intensities[rel.peaks.neg,], 2, median)
              .Object@neg.intensities <- t(t(.Object@neg.intensities)/med.tmp)
              cat("NEG:",length(rel.peaks.neg), "Peaks were used for median scaling.\n")

            }

            return(.Object)
          }
)

setGeneric(name="merge.technical.replicates",
           def=function(.Object, method)
           {
             standardGeneric("merge.technical.replicates")
           }
)

setMethod(f          = "merge.technical.replicates",
          signature  = "MSExperiment",
          definition = function(.Object, method = "median") {

            sample.ids <- unique(.Object@sample.description$sample)
            if(length(sample.ids) == nrow(.Object@sample.description)){
              warning("No technical replicated recognized (Please check you sample info sheet).Nothing was changed on the object.")
              return(.Object)
            }

            new.sample.name.pos <- paste0(sample.ids,"_","pos")
            new.sample.name.neg <- paste0(sample.ids,"_","neg")

            new.mat.pos <- matrix(NA, nrow = nrow(.Object@pos.intensities), ncol = length(sample.ids))
            new.mat.neg <- matrix(NA, nrow = nrow(.Object@neg.intensities), ncol = length(sample.ids))

            colnames(new.mat.pos) <- new.sample.name.pos
            colnames(new.mat.neg) <- new.sample.name.neg

            for(i in sample.ids) {


              # ~ ~ #
              # pos #
              # ~ ~ #
              pos.cn <- .Object@sample.description[sample == i, colname.pos]
              x.tmp  <- apply(.Object@pos.intensities[,pos.cn], 1, median, )
              new.mat.pos[, paste0(i,"_","pos")] <- x.tmp
              .Object@sample.description[sample == i, colname.pos := paste0(i,"_","pos")]


              # ~ ~ #
              # neg #
              # ~ ~ #
              neg.cn <- .Object@sample.description[sample == i, colname.neg]
              x.tmp  <- apply(.Object@neg.intensities[,neg.cn], 1, median)
              new.mat.neg[, paste0(i,"_","neg")] <- x.tmp
              .Object@sample.description[sample == i, colname.neg := paste0(i,"_","neg")]
            }

            .Object@pos.intensities <- new.mat.pos
            .Object@neg.intensities <- new.mat.neg

            .Object@sample.description <- .Object@sample.description[!duplicated(sample)]

            return(.Object)
          }
)


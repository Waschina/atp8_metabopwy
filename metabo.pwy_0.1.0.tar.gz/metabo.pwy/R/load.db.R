load.db <- function(source.db) {

  db.file <- system.file("extdata", paste0(source.db,"_BioChemDB.RDS"), package = "metabo.pwy")

  if(file.exists(db.file)) {
    db <- readRDS(db.file)
    return(db)
  } else {
    stop(paste0("Database (\"",source.db,"\") not found. Try \'build.db(source.db = \"",source.db,"\")\'."))
  }
}

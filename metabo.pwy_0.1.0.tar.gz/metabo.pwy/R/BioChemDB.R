#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# S4 Object for Biochemistry Database #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
BioChemDB <- setClass(
  # Name Of Class
  "BioChemDB",

  # Slot definition
  slots = c(
    source.db          = "character",
    met.db             = "data.table",
    adduct.ions        = "list",
    met.adducts        = "list",
    ppm.range          = "numeric",
    construction.date  = "character",
    metabo.pwy.version = "character"
  ),

  # Default Slot Values
  prototype = list()
)


setMethod(
  f          = "initialize",
  signature  = "BioChemDB",

  definition = function(.Object, db.source = "metacyc", ppm.range = 1) {

    # DB built info
    .Object@construction.date  <- date()
    .Object@metabo.pwy.version <- as.character(packageVersion("metabo.pwy"))
    .Object@ppm.range          <- ppm.range

    #~~~~~~~~~#
    # METACYC #
    #~~~~~~~~~#
    if(db.source == "metacyc") {
      .Object@source.db <- db.source

      # -- 1 -- #
      cat(paste0("Reading compound DB file ...\n"))
      mc.file <- system.file("extdata", "cpd_metacyc_200514.csv", package = "metabo.pwy")
      cpd.mc  <- data.table::fread(mc.file)

      cpd.mc  <- cpd.mc[, .(cpd.id = Compound, cpd.name = `Common-Name`, SMILES = SMILES, chem.formula = `Chemical Formula`)]
      #colnames(cpd.mc) <- c("cpd.id","cpd.name","SMILES","chem.formula")

      # Removing anorganic ions
      cpd.mc <- cpd.mc[!(chem.formula %in% c("Fe","Cr","Co","Mo","Hg","Ag","Ca","Ni","Mg","Cu","Cd","Zn","Mn","H","K","Li","Na","Rb",
                                             "Tl","NO2","La","Ti","Sb","Ti","V","Al","W","O2U","Be","Pt","Pb","Sr","Pd","Sn","Ba",
                                             "Cs",""))]

      # Remove arsenic compounds
      cpd.mc <- cpd.mc[!grepl("As", chem.formula)]

      # Remove cpd withut SMILES code
      cpd.mc <- cpd.mc[SMILES!=""]

      # get molecules
      #mols <- smiles2mol(cpd.mc$SMILES)

      # get metabolite charge
      cpd.mc[, cpd.charge := get.charge.from.smiles(SMILES), by = "cpd.id"]

      # Removing compounds with charge = NA
      cpd.mc <- cpd.mc[!is.na(cpd.charge)]

      # uncharge the charged
      #cpd.mc[, h.count := get.H.count(chem.formula), by = cpd.id]
      cpd.mc[cpd.charge < 0, add := paste0("H",-cpd.charge)]
      cpd.mc[cpd.charge > 0, add := paste0("H", cpd.charge)]
      cpd.mc[!is.na(add) & cpd.charge < 0, neutral.formula := addMolecules(chem.formula,add)$formula, by = cpd.id]
      cpd.mc[!is.na(add) & cpd.charge > 0, neutral.formula := ifelse(is.sub.valid(chem.formula,add),subMolecules(chem.formula,add)$formula,NA), by = cpd.id]
      cpd.mc[is.na(add) , neutral.formula := chem.formula]

      cpd.mc <- cpd.mc[!is.na(neutral.formula)]

      # Save met.db in slot
      .Object@met.db <- cpd.mc

    }

    #~~~~~~~~~~#
    # HUMANCYC #
    #~~~~~~~~~~#
    if(db.source == "humancyc") {
      .Object@source.db <- db.source

      # -- 1 -- #
      cat(paste0("Reading compound DB file ...\n"))
      mc.file <- system.file("extdata", "cpd_humancyc_200522_2.csv", package = "metabo.pwy")
      cpd.mc  <- data.table::fread(mc.file)

      cpd.mc  <- cpd.mc[, .(cpd.id = Compound, cpd.name = `Common-Name`, SMILES = SMILES, chem.formula = `Chemical Formula`)]
      #colnames(cpd.mc) <- c("cpd.id","cpd.name","SMILES","chem.formula")

      # Removing anorganic ions
      cpd.mc <- cpd.mc[!(chem.formula %in% c("Fe","Cr","Co","Mo","Hg","Ag","Ca","Ni","Mg","Cu","Cd","Zn","Mn","H","K","Li","Na","Rb",
                                             "Tl","NO2","La","Ti","Sb","Ti","V","Al","W","O2U","Be","Pt","Pb","Sr","Pd","Sn","Ba",
                                             "Cs",""))]

      # Remove arsenic compounds
      cpd.mc <- cpd.mc[!grepl("As", chem.formula)]

      # Remove cpd withut SMILES code
      cpd.mc <- cpd.mc[SMILES!=""]

      # Remove cpd withut chemical formula
      cpd.mc <- cpd.mc[chem.formula!=""]

      # get molecules
      #mols <- smiles2mol(cpd.mc$SMILES)

      # get metabolite charge
      cpd.mc[, cpd.charge := get.charge.from.smiles(SMILES), by = "cpd.id"]

      # Removing compounds with charge = NA
      cpd.mc <- cpd.mc[!is.na(cpd.charge)]

      # uncharge the charged
      #cpd.mc[, h.count := get.H.count(chem.formula), by = cpd.id]
      cpd.mc[cpd.charge < 0, add := paste0("H",-cpd.charge)]
      cpd.mc[cpd.charge > 0, add := paste0("H", cpd.charge)]
      cpd.mc[!is.na(add) & cpd.charge < 0, neutral.formula := addMolecules(chem.formula,add)$formula, by = cpd.id]
      cpd.mc[!is.na(add) & cpd.charge > 0, neutral.formula := ifelse(is.sub.valid(chem.formula,add),subMolecules(chem.formula,add)$formula,NA), by = cpd.id]
      cpd.mc[is.na(add) , neutral.formula := chem.formula]

      cpd.mc <- cpd.mc[!is.na(neutral.formula)]

      # Save met.db in slot
      .Object@met.db <- cpd.mc

    }


    #~~~~~~~~~~~~~~~#
    #  KEGG - Human #
    #~~~~~~~~~~~~~~~#
    else if(db.source == "kegg") {
      warning("KEGG DB currently only for human metabolism. Sorry.")

      .Object@source.db <- "kegg"

      cat(paste0("Reading compound DB file ...\n"))
      cpd.file <- system.file("extdata", "kegg_hsa_cpd_200715.csv", package = "metabo.pwy")
      cpd.kegg <- data.table::fread(cpd.file)

      cpd.kegg  <- cpd.kegg[, .(cpd.id = cpd, cpd.name, chem.formula = neutral.formula)]

      # Removing non-specific sum formula
      cpd.kegg <- cpd.kegg[!grepl("(\\)[0-9]*n)|(R)|(\\.)", chem.formula)]

      # Removing anorganic ions/atoms
      cpd.kegg <- cpd.kegg[!(chem.formula %in% c("Fe","Cr","Co","Mo","Hg","Ag","Ca","Ni","Mg","Cu","Cd","Zn","Mn","H","K","Li","Na","Rb",
                                                 "Tl","NO2","La","Ti","Sb","Ti","V","Al","W","O2U","Be","Pt","Pb","Sr","Pd","Sn","Ba",
                                                 "Cs",""))]

      # Remove arsenic compounds
      cpd.kegg <- cpd.kegg[!grepl("As", chem.formula)]


      cpd.kegg[, neutral.formula := chem.formula]

      # Save met.db in slot
      .Object@met.db <- cpd.kegg

    } else {
      stop("Unknow Source DB (ask Silvio)")
    }

    # following steps shoul be independend of the source DB

    # -- 2 -- #
    cat(paste0("Reading adduct ion list ...\n"))
    ad.file <- system.file("extdata", "adducts.csv", package = "metabo.pwy")
    ad.all  <- fread(ad.file)

    ad.pos <- ad.all[ion.mode == "positive"]
    ad.neg <- ad.all[ion.mode == "negative"]

    .Object@adduct.ions <- list(pos = ad.pos,
                                neg = ad.neg)

    # -- 3 -- #
    cat(paste0("Calculating metabolite-X-adduct combinations ... "))

    uniq.formulas <- unique(.Object@met.db$neutral.formula)#[1:500]
    n.cpd <-length(uniq.formulas)
    cat(n.cpd, "(unique neutral formulas)\n")

    #~~~~~~~~~~~~~~~#
    # Positive mode #
    #~~~~~~~~~~~~~~~#
    met.adducts.pos <- list()
    if(nrow(.Object@adduct.ions$pos) > 0) {
      cat("Calculating (pos) ...\n")
      k <- 1
      for(i in uniq.formulas) {
        cat("\r",k,"/",n.cpd)
        met.adducts.pos[[i]] <- get.met.adducts(i, .Object@adduct.ions$pos)
        k <- k + 1
      }
      met.adducts.pos <- rbindlist(met.adducts.pos, idcol = "neutral.formula")
      met.adducts.pos <- met.adducts.pos[, .(adduct, ion.mode, charge, formula, neutral.formula)]
      met.adducts.pos[, mz.pred := mz.calculator(formula, charge)]
      met.adducts.pos[, mz.ppme := mz.ppm.range(mz.pred, ppm.range)]
      cat("\n")
    }

    #~~~~~~~~~~~~~~~#
    # Negative mode #
    #~~~~~~~~~~~~~~~#
    met.adducts.neg <- list()
    if(nrow(.Object@adduct.ions$neg) > 0) {
      cat("Calculating (neg) ...\n")
      k <- 1
      for(i in uniq.formulas) {
        cat("\r",k,"/",n.cpd)
        met.adducts.neg[[i]] <- get.met.adducts(i, .Object@adduct.ions$neg)
        k <- k + 1
      }
      met.adducts.neg <- rbindlist(met.adducts.neg, idcol = "neutral.formula")
      met.adducts.neg <- met.adducts.neg[, .(adduct, ion.mode, charge, formula, neutral.formula)]
      met.adducts.neg[, mz.pred := mz.calculator(formula, charge)]
      met.adducts.neg[, mz.ppme := mz.ppm.range(mz.pred, ppm.range)]
      cat("\n")
    }

    .Object@met.adducts <- list(pos = met.adducts.pos,
                                neg = met.adducts.neg)

    return(.Object)
  }
)


setGeneric(name="filter.adduct.ions",
           def=function(.Object)
           {
             standardGeneric("filter.adduct.ions")
           }
)

setMethod(f          = "filter.adduct.ions",
          signature  = "BioChemDB",
          definition = function(.Object) {

            # open interactive selection window

            sel.pos <-tk_select.list(.Object@adduct.ions$pos[, adduct], preselect = NULL, multiple = TRUE,
                                     title = "Please select postive adducts.")

            sel.neg <-tk_select.list(.Object@adduct.ions$neg[, adduct], preselect = NULL, multiple = TRUE,
                                     title = "Please select negative adducts.")

            # apply selection
            .Object@adduct.ions$pos <- .Object@adduct.ions$pos[adduct %in% sel.pos]
            .Object@adduct.ions$neg <- .Object@adduct.ions$neg[adduct %in% sel.neg]

            .Object@met.adducts$pos <- .Object@met.adducts$pos[adduct %in% sel.pos]
            .Object@met.adducts$neg <- .Object@met.adducts$neg[adduct %in% sel.neg]


            return(.Object)
          }
)

setGeneric(name="reset.ppm.range",
           def=function(.Object, ppm.range)
           {
             standardGeneric("reset.ppm.range")
           }
)

setMethod(f          = "reset.ppm.range",
          signature  = "BioChemDB",
          definition = function(.Object, ppm.range) {

            .Object@ppm.range <- ppm.range

            # this complicated "copy"-thing is required because data.table updated table entried in place
            # thus, first make a hard copy, update numbers and save in slot "met.adducts"
            .Object@met.adducts$pos <- copy(.Object@met.adducts$pos)[, mz.ppme := mz.ppm.range(mz.pred, ppm.range)]
            .Object@met.adducts$neg <- copy(.Object@met.adducts$neg)[, mz.ppme := mz.ppm.range(mz.pred, ppm.range)]


            return(.Object)
          }
)

# method todos
# 1. filter adducts
# 2. reset ppm range

mz.calculator <- function(formula, charge) {
  if(length(formula) != length(charge))
    stop("Unequal length of formula and charge")

  m.e <- 0.00054857990924 # mass electron
  out <- c()

  for(i in 1:length(formula)){
    if(charge[i]==0) {
      out[i] <- NA_real_
    } else {
      mol      <- Rdisop::getMolecule(formula = formula[i])
      mol.mass <- Rdisop::getMass(mol)
      out[i]   <- (mol.mass - charge[i] * m.e) / abs(charge[i])
    }

  }
  return(out)
}

mz.ppm.range <- function(x, ppm = 1) {
  out <- x * ppm / 1000000
  return(out)
}

get.met.adducts <- function(formula, adducts) {
  met.a    <- copy(adducts)
  tmp.frml <- formula

  # get formula based on M stoichiometry
  met.a$formula <- tmp.frml
  met.a[M.stoichiometry == 2, formula := addMolecules(tmp.frml, tmp.frml)$formula]
  met.a[M.stoichiometry == 3, formula := addMolecules(addMolecules(tmp.frml, tmp.frml)$formula, tmp.frml)$formula]

  # add plus.ion(s)
  met.a[plus.ion != "", formula := addMolecules(formula, plus.ion)$formula, by = "adduct"]

  # sub minus.ion(s)
  met.a[, sub.valid := F]
  for(i in 1:nrow(met.a)) {
    met.a[i, sub.valid := is.sub.valid(formula, minus.ion)]
  }
  met.a <- met.a[sub.valid == T]
  met.a[minus.ion != "", formula := subMolecules(formula, minus.ion)$formula, by = "adduct"]

  return(met.a)
}

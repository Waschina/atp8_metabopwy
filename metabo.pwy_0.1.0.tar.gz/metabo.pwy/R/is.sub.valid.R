is.sub.valid <- function(frml1, frml2) {
  # empty formula 1
  if(frml1=="")
    return(FALSE)

  # no substraction
  if(frml2=="")
    return(TRUE)

  m1 <- makeup(frml1)
  m2 <- makeup(frml2)

  # one or more element(s) in frml2 not present in frml1
  if(!all(names(m2) %in% names(m1)))
    return(FALSE)

  # any element number in frml2 higher than in frml1
  if(any((m1[match(names(m2),names(m1))] - m2) < 0))
    return(FALSE)

  # after sub only empty formula
  if(all((m1[match(names(m2),names(m1))] - m2) == 0))
    return(FALSE)

  return(TRUE)
}

build.db <- function(source.db) {
  db <- new("BioChemDB",
            db.source = source.db)

  package.dir <- system.file("extdata", "", package = "metabo.pwy")

  saveRDS(db, file = paste0(package.dir,source.db,"_BioChemDB.RDS"))
}

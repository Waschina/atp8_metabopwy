init.msexp <- function(name, file.pos, file.neg, sample.info) {
  require(bit64)

  sample.description <- fread(sample.info)

  # scaling factor to get numbers from integer64 to double if neseccary
  sc.fac <- 1
  dt.pos <- fread(file.pos)
  dt.neg <- fread(file.neg)
  if(any(unlist(lapply(dt.pos, class)) == "integer64") | any(unlist(lapply(dt.neg, class)) == "integer64"))
    sc.fac <- 100000

  # pos
  for(k in sample.description$colname.pos)
    dt.pos[[k]] <- as.double(dt.pos[[k]]/sc.fac)

  # neg
  for(k in sample.description$colname.neg)
    dt.neg[[k]] <- as.double(dt.neg[[k]]/sc.fac)

  spl.pos <- as.character(sample.description$colname.pos)
  mat.pos <- as.matrix(dt.pos[,..spl.pos])

  spl.neg <- as.character(sample.description$colname.neg)
  mat.neg <- as.matrix(dt.neg[,..spl.neg])

  pos.mz <- dt.pos$`m/z meas.`
  neg.mz <- dt.neg$`m/z meas.`

  msexp <- new("MSExperiment",
               exp.name = name,
               sample.description = sample.description,
               pos.intensities    = mat.pos,
               neg.intensities    = mat.neg,
               pos.mz             = pos.mz,
               neg.mz             = neg.mz
  )

  return(msexp)
}

get.charge.from.smiles <- function(x) {

  zut <- tryCatch({parse.smiles(x)[[1]]}, error=function(cond) {return(NA)})

  if(is.null(zut)){
    return(NA)
  }
  tmp <- sum(unlist(lapply(get.atoms(zut), get.formal.charge)))
  return(tmp)
}
